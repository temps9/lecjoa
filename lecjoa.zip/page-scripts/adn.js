/******recupere les valeurs entrer*/
function regarde() {
/*********met en memoire valeur css 1*****/
var input1 = document.getElementById("Nb1");
localStorage.removeItem("nb1", input1.value);
localStorage.setItem("nb1", input1.value);
donne1 = localStorage.getItem("nb1");

/*********met en memoire valeur css 2*****/
var input2 = document.getElementById("Nb2");
localStorage.removeItem("nb2", input2.value);
localStorage.setItem("nb2", input2.value);
donne2 = localStorage.getItem("nb2");

/*********met en memoire valeur css 3 *****/
var input3 = document.getElementById("Nb3");
localStorage.removeItem("nb3", input3.value);
localStorage.setItem("nb3", input3.value);
donne3 = localStorage.getItem("nb3");

/*********met en memoire valeur css 4 *****/
var input4 = document.getElementById("Nb4");
localStorage.removeItem("nb4", input4.value);
localStorage.setItem("nb4", input4.value);
donne4 = localStorage.getItem("nb4");

/*********met en memoire valeur css 5 *****/
var input5 = document.getElementById("Nb5");
localStorage.removeItem("nb5", input5.value);
localStorage.setItem("nb5", input5.value);
donne5 = localStorage.getItem("nb5");

/*********met en memoire valeur css 6 *****/
var input6 = document.getElementById("Nb6");
localStorage.removeItem("nb6", input6.value);
localStorage.setItem("nb6", input6.value);
donne6 = localStorage.getItem("nb6");

/*********met en memoire valeur css 7 *****/
var input7 = document.getElementById("Nb7");
localStorage.removeItem("nb7", input7.value);
localStorage.setItem("nb7", input7.value);
donne7 = localStorage.getItem("nb7");

/*********met en memoire valeur css 8 *****/
var input8 = document.getElementById("Nb8");
localStorage.removeItem("nb8", input8.value);
localStorage.setItem("nb8", input8.value);
donne8 = localStorage.getItem("nb8");

/*********met en memoire valeur css 9 *****/
var input9 = document.getElementById("Nb9");
localStorage.removeItem("nb9", input9.value);
localStorage.setItem("nb9", input9.value);
donne9 = localStorage.getItem("nb9");

/*********met en memoire valeur css 10 *****/
var input10 = document.getElementById("Nb10");
localStorage.removeItem("nb10", input10.value);
localStorage.setItem("nb10", input10.value);
donne10 = localStorage.getItem("nb10");

/*********met en memoire valeur css 11 *****/
var input11 = document.getElementById("Nb11");
localStorage.removeItem("nb11", input11.value);
localStorage.setItem("nb11", input11.value);
donne11 = localStorage.getItem("nb11");

/*********met en memoire valeur css 12*****/
var input12 = document.getElementById("Nb12");
localStorage.removeItem("nb12", input12.value);
localStorage.setItem("nb12", input12.value);
donne12 = localStorage.getItem("nb12");

/*********met en memoire valeur css 13*****/
var input13 = document.getElementById("Nb13");
localStorage.removeItem("nb13", input13.value);
localStorage.setItem("nb13", input13.value);
donne13 = localStorage.getItem("nb13");

/*********met en memoire valeur css 14*****/
var input14 = document.getElementById("Nb14");
localStorage.removeItem("nb14", input14.value);
localStorage.setItem("nb14", input14.value);
donne14 = localStorage.getItem("nb14");

/*********met en memoire valeur css 15*****/
var input15 = document.getElementById("Nb15");
localStorage.removeItem("nb15", input15.value);
localStorage.setItem("nb15", input15.value);
donne15 = localStorage.getItem("nb15");

/*********met en memoire valeur css 16*****/
var input16 = document.getElementById("Nb16");
localStorage.removeItem("nb16", input16.value);
localStorage.setItem("nb16", input16.value);
donne16 = localStorage.getItem("nb16");

/*********met en memoire valeur css 17*****/
var input17 = document.getElementById("Nb17");
localStorage.removeItem("nb17", input17.value);
localStorage.setItem("nb17", input17.value);
donne17 = localStorage.getItem("nb17");

/*********met en memoire valeur css 18*****/
var input18 = document.getElementById("Nb18");
localStorage.removeItem("nb18", input18.value);
localStorage.setItem("nb18", input18.value);
donne18 = localStorage.getItem("nb18");

/*********met en memoire valeur css 19*****/
var input19 = document.getElementById("Nb19");
localStorage.removeItem("nb19", input19.value);
localStorage.setItem("nb19", input19.value);
donne19 = localStorage.getItem("nb19");

/*********met en memoire valeur css 20*****/
var input20 = document.getElementById("Nb20");
localStorage.removeItem("nb20", input20.value);
localStorage.setItem("nb20", input20.value);
donne20 = localStorage.getItem("nb20");

/*********met en memoire valeur css 21*****/
var input21 = document.getElementById("Nb21");
localStorage.removeItem("nb21", input21.value);
localStorage.setItem("nb21", input21.value);
donne21 = localStorage.getItem("nb21");

/*********met en memoire valeur css 22*****/
var input22 = document.getElementById("Nb22");
localStorage.removeItem("nb22", input22.value);
localStorage.setItem("nb22", input22.value);
donne22 = localStorage.getItem("nb22");

/*********met en memoire valeur css 23*****/
var input23 = document.getElementById("Nb23");
localStorage.removeItem("nb23", input23.value);
localStorage.setItem("nb23", input23.value);
donne23 = localStorage.getItem("nb23");

/*********met en memoire valeur css 24*****/
var input24 = document.getElementById("Nb24");
localStorage.removeItem("nb24", input24.value);
localStorage.setItem("nb24", input24.value);
donne24 = localStorage.getItem("nb24");

/*********met en memoire valeur css 25*****/
var input25 = document.getElementById("Nb25");
localStorage.removeItem("nb25", input25.value);
localStorage.setItem("nb25", input25.value);
donne25 = localStorage.getItem("nb25");

/*********met en memoire valeur css 26*****/
var input26 = document.getElementById("Nb26");
localStorage.removeItem("nb26", input26.value);
localStorage.setItem("nb26", input26.value);
donne26 = localStorage.getItem("nb26");

/*********met en memoire valeur css 27*****/
var input27 = document.getElementById("Nb27");
localStorage.removeItem("nb27", input27.value);
localStorage.setItem("nb27", input27.value);
donne27 = localStorage.getItem("nb27");

/*********met en memoire valeur css 28*****/
var input28 = document.getElementById("Nb28");
localStorage.removeItem("nb28", input28.value);
localStorage.setItem("nb28", input28.value);
donne28 = localStorage.getItem("nb28");

/*********met en memoire valeur css 29*****/
var input29 = document.getElementById("Nb29");
localStorage.removeItem("nb29", input29.value);
localStorage.setItem("nb29", input29.value);
donne29 = localStorage.getItem("nb29");

/*********met en memoire valeur css 30*****/
var input30 = document.getElementById("Nb30");
localStorage.removeItem("nb30", input30.value);
localStorage.setItem("nb30", input30.value);
donne30 = localStorage.getItem("nb30");

/*********met en memoire valeur css 31*****/
var input31 = document.getElementById("Nb31");
localStorage.removeItem("nb31", input31.value);
localStorage.setItem("nb31", input31.value);
donne31 = localStorage.getItem("nb31");

/*********met en memoire valeur css 32*****/
var input32 = document.getElementById("Nb32");
localStorage.removeItem("nb32", input32.value);
localStorage.setItem("nb32", input32.value);
donne32 = localStorage.getItem("nb32");

/*********met en memoire valeur css 33*****/
var input33 = document.getElementById("Nb33");
localStorage.removeItem("nb33", input33.value);
localStorage.setItem("nb33", input33.value);
donne33 = localStorage.getItem("nb33");

/*********met en memoire valeur css 34*****/
var input34 = document.getElementById("Nb34");
localStorage.removeItem("nb34", input34.value);
localStorage.setItem("nb34", input34.value);
donne34 = localStorage.getItem("nb34");

/*********met en memoire valeur css 35*****/
var input35 = document.getElementById("Nb35");
localStorage.removeItem("nb35", input35.value);
localStorage.setItem("nb35", input35.value);
donne35 = localStorage.getItem("nb35");

/*********met en memoire valeur css 36*****/
var input36 = document.getElementById("Nb36");
localStorage.removeItem("nb36", input36.value);
localStorage.setItem("nb36", input36.value);
donne36 = localStorage.getItem("nb36");

/*********met en memoire valeur css 37*****/
var input37 = document.getElementById("Nb37");
localStorage.removeItem("nb37", input37.value);
localStorage.setItem("nb37", input37.value);
donne37 = localStorage.getItem("nb37");

/*********met en memoire valeur css 38*****/
var input38 = document.getElementById("Nb38");
localStorage.removeItem("nb38", input38.value);
localStorage.setItem("nb38", input38.value);
donne38 = localStorage.getItem("nb38");

/*********met en memoire valeur css 39*****/
var input39 = document.getElementById("Nb39");
localStorage.removeItem("nb39", input39.value);
localStorage.setItem("nb39", input39.value);
donne39 = localStorage.getItem("nb39");

/*********met en memoire valeur css 40*****/
var input40 = document.getElementById("Nb40");
localStorage.removeItem("nb40", input40.value);
localStorage.setItem("nb40", input40.value);
donne40 = localStorage.getItem("nb40");

/*********met en memoire valeur css 41*****/
var input41 = document.getElementById("Nb41");
localStorage.removeItem("nb41", input41.value);
localStorage.setItem("nb41", input41.value);
donne41 = localStorage.getItem("nb41");

/*********met en memoire valeur css 42*****/
var input42 = document.getElementById("Nb42");
localStorage.removeItem("nb42", input42.value);
localStorage.setItem("nb42", input42.value);
donne42 = localStorage.getItem("nb42");

/*********met en memoire valeur css 43*****/
var input43 = document.getElementById("Nb43");
localStorage.removeItem("nb43", input43.value);
localStorage.setItem("nb43", input43.value);
donne43 = localStorage.getItem("nb43");

/*********met en memoire valeur css 44*****/
var input44 = document.getElementById("Nb44");
localStorage.removeItem("nb44", input44.value);
localStorage.setItem("nb44", input44.value);
donne44 = localStorage.getItem("nb44");

/*********met en memoire valeur css 45*****/
var input45 = document.getElementById("Nb45");
localStorage.removeItem("nb45", input45.value);
localStorage.setItem("nb45", input45.value);
donne45 = localStorage.getItem("nb45");

/*********met en memoire valeur css 46*****/
var input46 = document.getElementById("Nb46");
localStorage.removeItem("nb46", input46.value);
localStorage.setItem("nb46", input46.value);
donne46 = localStorage.getItem("nb46");

/*********met en memoire valeur css 47*****/
var input47 = document.getElementById("Nb47");
localStorage.removeItem("nb47", input47.value);
localStorage.setItem("nb47", input47.value);
donne47 = localStorage.getItem("nb47");

/*********met en memoire valeur css 48*****/
var input48 = document.getElementById("Nb48");
localStorage.removeItem("nb48", input48.value);
localStorage.setItem("nb48", input48.value);
donne48 = localStorage.getItem("nb48");

/*********met en memoire valeur css 49*****/
var input49 = document.getElementById("Nb49");
localStorage.removeItem("nb49", input49.value);
localStorage.setItem("nb49", input49.value);
donne49 = localStorage.getItem("nb49");

/*********met en memoire valeur css 50*****/
var input50 = document.getElementById("Nb50");
localStorage.removeItem("nb50", input50.value);
localStorage.setItem("nb50", input50.value);
donne50 = localStorage.getItem("nb50");

/*********met en memoire valeur css 51*****/
var input51 = document.getElementById("Nb51");
localStorage.removeItem("nb51", input51.value);
localStorage.setItem("nb51", input51.value);
donne51 = localStorage.getItem("nb51");

/*********met en memoire valeur css 52*****/
var input52 = document.getElementById("Nb52");
localStorage.removeItem("nb52", input52.value);
localStorage.setItem("nb52", input52.value);
donne52 = localStorage.getItem("nb52");

/*********met en memoire valeur css 53*****/
var input53 = document.getElementById("Nb53");
localStorage.removeItem("nb53", input53.value);
localStorage.setItem("nb53", input53.value);
donne53 = localStorage.getItem("nb53");

/*********met en memoire valeur css 54*****/
var input54 = document.getElementById("Nb54");
localStorage.removeItem("nb54", input54.value);
localStorage.setItem("nb54", input54.value);
donne54 = localStorage.getItem("nb54");

/*********met en memoire valeur css 55*****/
var input55 = document.getElementById("Nb55");
localStorage.removeItem("nb55", input55.value);
localStorage.setItem("nb55", input55.value);
donne55 = localStorage.getItem("nb55");

/*********met en memoire valeur css 56*****/
var input56 = document.getElementById("Nb56");
localStorage.removeItem("nb56", input56.value);
localStorage.setItem("nb56", input56.value);
donne56 = localStorage.getItem("nb56");

/*********met en memoire valeur css 57*****/
var input57 = document.getElementById("Nb57");
localStorage.removeItem("nb57", input57.value);
localStorage.setItem("nb57", input57.value);
donne57 = localStorage.getItem("nb57");

/*********met en memoire valeur css 58*****/
var input58 = document.getElementById("Nb58");
localStorage.removeItem("nb58", input58.value);
localStorage.setItem("nb58", input58.value);
donne58 = localStorage.getItem("nb58");

/*********met en memoire valeur css 59*****/
var input59 = document.getElementById("Nb59");
localStorage.removeItem("nb59", input59.value);
localStorage.setItem("nb59", input59.value);
donne59 = localStorage.getItem("nb59");

/*********met en memoire valeur css 60*****/
var input60 = document.getElementById("Nb60");
localStorage.removeItem("nb60", input60.value);
localStorage.setItem("nb60", input60.value);
donne60 = localStorage.getItem("nb60");

/*********met en memoire valeur css 61*****/
var input61 = document.getElementById("Nb61");
localStorage.removeItem("nb61", input61.value);
localStorage.setItem("nb61", input61.value);
donne61 = localStorage.getItem("nb61");

/*********met en memoire valeur css 62*****/
var input62 = document.getElementById("Nb62");
localStorage.removeItem("nb62", input62.value);
localStorage.setItem("nb62", input62.value);
donne62 = localStorage.getItem("nb62");

/*********met en memoire valeur css 63*****/
var input63 = document.getElementById("Nb63");
localStorage.removeItem("nb63", input63.value);
localStorage.setItem("nb63", input63.value);
donne63 = localStorage.getItem("nb63");

/*********met en memoire valeur css 64*****/
var input64 = document.getElementById("Nb64");
localStorage.removeItem("nb64", input64.value);
localStorage.setItem("nb64", input64.value);
donne64 = localStorage.getItem("nb64");

/*********met en memoire valeur css 65*****/
var input65 = document.getElementById("Nb65");
localStorage.removeItem("nb65", input65.value);
localStorage.setItem("nb65", input65.value);
donne65 = localStorage.getItem("nb65");

/*********met en memoire valeur css 66*****/
var input66 = document.getElementById("Nb66");
localStorage.removeItem("nb66", input66.value);
localStorage.setItem("nb66", input66.value);
donne66 = localStorage.getItem("nb66");

/*********met en memoire valeur css 67*****/
var input67 = document.getElementById("Nb67");
localStorage.removeItem("nb67", input67.value);
localStorage.setItem("nb67", input67.value);
donne67 = localStorage.getItem("nb67");

/*********met en memoire valeur css 68*****/
var input68 = document.getElementById("Nb68");
localStorage.removeItem("nb68", input68.value);
localStorage.setItem("nb68", input68.value);
donne68 = localStorage.getItem("nb68");

/*********met en memoire valeur css 69*****/
var input69 = document.getElementById("Nb69");
localStorage.removeItem("nb69", input69.value);
localStorage.setItem("nb69", input69.value);
donne69 = localStorage.getItem("nb69");

/*********met en memoire valeur css 70*****/
var input70 = document.getElementById("Nb70");
localStorage.removeItem("nb70", input70.value);
localStorage.setItem("nb70", input70.value);
donne70 = localStorage.getItem("nb70");

/*********met en memoire valeur css 71*****/
var input71 = document.getElementById("Nb71");
localStorage.removeItem("nb71", input71.value);
localStorage.setItem("nb71", input71.value);
donne71 = localStorage.getItem("nb71");

/*********met en memoire valeur css 71*****/
var input72 = document.getElementById("Nb72");
localStorage.removeItem("nb72", input72.value);
localStorage.setItem("nb72", input72.value);
donne72 = localStorage.getItem("nb72");

/*********met en memoire valeur css 71*****/
var input73 = document.getElementById("Nb73");
localStorage.removeItem("nb73", input73.value);
localStorage.setItem("nb73", input73.value);
donne73 = localStorage.getItem("nb73");
}

/*********************/    
   
			var FichierAudioJo=[];
			var FichierAudioJox=[];
var text1={};
var choixjojoa = 1;
var levariateur = 1;
var lenommeur ;
var lenommeur1 ;





/*********************************deuxième partie*********************************************************************************/


/********************************fin deuxième partie******/



/***********troisième partie**********application qui met aux normes audio actuelles*********/


/******fin de la troisième partie**encodeur aux normes audio*************************/


/***********cinquième partie génère la balise et lance la lecture**************/



function genereLaFin()
{

/**************genere balise*******/


lenommeur1= "basewave";


levariateur = levariateur + 1;


lenommeur = lenommeur1.concat(levariateur); 
switch(levariateur) {
    case 2:

//zone 1
var mon_audio1 = null;
var nouveauaudio1 = null;
var nouveauaudio1a = null;

function ajouteElement() {
  // crée un nouvel élément audio

  nouveauaudio1 =  document.createElement("audio");
nouveauaudio1.setAttribute("id", "audiojoa");
nouveauaudio1.setAttribute("controls", "controls");
nouveauaudio1.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio1a = document.createElement("source");


  nouveauaudio1a.setAttribute("src", "data:audio/wav;basewave2,");
   nouveauaudio1.appendChild(nouveauaudio1a);
  mon_audio1 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio1, mon_audio1);
}  

ajouteElement();

//fin zone 1

        break;
    case 3:
//zone 2
var mon_audio2 = null;
var nouveauaudio2 = null;
var nouveauaudio2a = null;


function ajouteElement1() {
  // crée un nouvel élément audio

  nouveauaudio2 =  document.createElement("audio");
nouveauaudio2.setAttribute("id", "audiojoa1");
nouveauaudio2.setAttribute("controls", "controls");
nouveauaudio2.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio2a = document.createElement("source");


  nouveauaudio2a.setAttribute("src", "data:audio/wav;basewave3,");
   nouveauaudio2.appendChild(nouveauaudio2a);
  mon_audio2 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio2, mon_audio2);

}  

ajouteElement1();

//fin zone 2
        break;
    case 4:
//zone 3
var mon_audio3 = null;
var nouveauaudio3 = null;
var nouveauaudio3a = null;

function ajouteElement2() {
  // crée un nouvel élément audio

  nouveauaudio3 =  document.createElement("audio");
nouveauaudio3.setAttribute("id", "audiojoa2");
nouveauaudio3.setAttribute("controls", "controls");
nouveauaudio3.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio3a = document.createElement("source");


  nouveauaudio3a.setAttribute("src", "data:audio/wav;basewave4,");
   nouveauaudio3.appendChild(nouveauaudio3a);
  mon_audio3 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio3, mon_audio3);

}  
ajouteElement2();
        break;
//fin zone 3
//zone 4
    case 5:
var mon_audio4 = null;
var nouveauaudio4 = null;
var nouveauaudio4a = null;

function ajouteElement3() {
  // crée un nouvel élément audio

  nouveauaudio4 =  document.createElement("audio");
nouveauaudio4.setAttribute("id", "audiojoa3");
nouveauaudio4.setAttribute("controls", "controls");
nouveauaudio4.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio4a = document.createElement("source");


  nouveauaudio4a.setAttribute("src", "data:audio/wav;basewave5,");
   nouveauaudio4.appendChild(nouveauaudio4a);
  mon_audio4 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio4, mon_audio4);

}  
ajouteElement3();
        break;
//fin zone 4
/***/
    case 6:
//zone 5
var mon_audio5 = null;
var nouveauaudio5 = null;
var nouveauaudio5a = null;

function ajouteElement4() {
  // crée un nouvel élément audio

  nouveauaudio5 =  document.createElement("audio");
nouveauaudio5.setAttribute("id", "audiojoa4");
nouveauaudio5.setAttribute("controls", "controls");
nouveauaudio5.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio5a = document.createElement("source");


  nouveauaudio5a.setAttribute("src", "data:audio/wav;basewave6,");
   nouveauaudio5.appendChild(nouveauaudio5a);
  mon_audio5 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio5, mon_audio5);

}  
ajouteElement4();


//fin zone 5

        break;
/***/
    case 7:
//zone 6
var mon_audio6 = null;
var nouveauaudio6 = null;
var nouveauaudio6a = null;

function ajouteElement5() {
  // crée un nouvel élément audio

  nouveauaudio6 =  document.createElement("audio");
nouveauaudio6.setAttribute("id", "audiojoa5");
nouveauaudio6.setAttribute("controls", "controls");
nouveauaudio6.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio6a = document.createElement("source");


  nouveauaudio6a.setAttribute("src", "data:audio/wav;basewave7,");
   nouveauaudio6.appendChild(nouveauaudio6a);
  mon_audio6 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio6, mon_audio6);

}  
ajouteElement5();


//fin zone 6

        break;
/***/
    case 8:
//zone 7
var mon_audio7 = null;
var nouveauaudio7 = null;
var nouveauaudio7a = null;

function ajouteElement6() {
  // crée un nouvel élément audio

  nouveauaudio7 =  document.createElement("audio");
nouveauaudio7.setAttribute("id", "audiojoa6");
nouveauaudio7.setAttribute("controls", "controls");
nouveauaudio7.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio7a = document.createElement("source");


  nouveauaudio7a.setAttribute("src", "data:audio/wav;basewave8,");
   nouveauaudio7.appendChild(nouveauaudio7a);
  mon_audio7 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio7, mon_audio7);

}  
ajouteElement6();


//fin zone 7

        break;
/***/

    case 9:
//zone 8
var mon_audio8 = null;
var nouveauaudio8 = null;
var nouveauaudio8a = null;

function ajouteElement7() {
  // crée un nouvel élément audio

  nouveauaudio8 =  document.createElement("audio");
nouveauaudio8.setAttribute("id", "audiojoa7");
nouveauaudio8.setAttribute("controls", "controls");
nouveauaudio8.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio8a = document.createElement("source");


  nouveauaudio8a.setAttribute("src", "data:audio/wav;basewave9,");
   nouveauaudio8.appendChild(nouveauaudio8a);
  mon_audio8 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio8, mon_audio8);

}  
ajouteElement7();


//fin zone 8

        break;
/***/

    case 10:
//zone 9
var mon_audio9 = null;
var nouveauaudio9 = null;
var nouveauaudio9a = null;

function ajouteElement8() {
  // crée un nouvel élément audio

  nouveauaudio9 =  document.createElement("audio");
nouveauaudio9.setAttribute("id", "audiojoa8");
nouveauaudio9.setAttribute("controls", "controls");
nouveauaudio9.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio9a = document.createElement("source");


  nouveauaudio9a.setAttribute("src", "data:audio/wav;basewave10,");
   nouveauaudio9.appendChild(nouveauaudio9a);
  mon_audio9 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio9, mon_audio9);

}  
ajouteElement8();


//fin zone 9

        break;
/***/

    default:
//zone 10
var mon_audio10 = null;
var nouveauaudio10 = null;
var nouveauaudio10a = null;

function ajouteElement9() {
  // crée un nouvel élément audio

  nouveauaudio10 =  document.createElement("audio");
nouveauaudio10.setAttribute("id", "audiojoa9");
nouveauaudio10.setAttribute("controls", "controls");
nouveauaudio10.setAttribute("autobuffer", " ");

  // ajoute l'élément qui vient d'être créé et son contenu au DOM

 nouveauaudio10a = document.createElement("source");


  nouveauaudio10a.setAttribute("src", "data:audio/wav;basewave11,");
   nouveauaudio10.appendChild(nouveauaudio10a);
  mon_audio10 = document.getElementById(lenommeur);
  document.body.insertBefore(nouveauaudio10, mon_audio10);

}  
ajouteElement9();


//fin zone 10

} // fin switch





/**reglage force de l'amplitude***/
var volume = Math.floor(65535 / 8);

durerentete=NbPtTotal*2;

samples = durerentete*16;
var data = {};

 data = {leraw: leraw.join(''), samples: samples};

var wave = new app.wave(data);

/*********met en memoire l'audio*****/





 lenommeur = wave.generate();

sessionStorage.removeItem("MaMemoireAudio");
sessionStorage.setItem("MaMemoireAudio","lenommeur")
//var wave1 = sessionStorage.getItem("MaMemoireAudio");


switch(levariateur) {
    case 2:
var audio = document.getElementById("audiojoa");
var source = document.createElement("source");
source.setAttribute("src", lenommeur);
audio.appendChild(source);
        break;
    case 3:
var audio1 = document.getElementById("audiojoa1");
var source1 = document.createElement("source");
source1.setAttribute("src", lenommeur);
audio1.appendChild(source1);
        break;
    case 4:
var audio2 = document.getElementById("audiojoa2");
var source2 = document.createElement("source");
source2.setAttribute("src", lenommeur);
audio2.appendChild(source2);
        break;
    case 5:
var audio3 = document.getElementById("audiojoa3");
var source3 = document.createElement("source");
source3.setAttribute("src", lenommeur);
audio3.appendChild(source3);
        break;

    case 6:
var audio4 = document.getElementById("audiojoa4");
var source4 = document.createElement("source");
source4.setAttribute("src", lenommeur);
audio4.appendChild(source4);
        break;

    case 7:
var audio5 = document.getElementById("audiojoa5");
var source5 = document.createElement("source");
source5.setAttribute("src", lenommeur);
audio5.appendChild(source5);
        break;

    case 8:
var audio6 = document.getElementById("audiojoa6");
var source6 = document.createElement("source");
source6.setAttribute("src", lenommeur);
audio6.appendChild(source6);
        break;

    case 9:
var audio7 = document.getElementById("audiojoa7");
var source7 = document.createElement("source");
source7.setAttribute("src", lenommeur);
audio7.appendChild(source7);
        break;

    case 10:
var audio8 = document.getElementById("audiojoa8");
var source8 = document.createElement("source");
source8.setAttribute("src", lenommeur);
audio8.appendChild(source8);
        break;

    case 11:
var audio9 = document.getElementById("audiojoa9");
var source9 = document.createElement("source");
source9.setAttribute("src", lenommeur);
audio9.appendChild(source9);
        break;
    case 12:
var audio10 = document.getElementById("audiojoa10");
var source10 = document.createElement("source");
source10.setAttribute("src", lenommeur);
audio10.appendChild(source10);
        break;
    case 13:
var audio11 = document.getElementById("audiojoa11");
var source11 = document.createElement("source");
source11.setAttribute("src", lenommeur);
audio11.appendChild(source11);
        break;
    case 14:
var audio12 = document.getElementById("audiojoa12");
var source12 = document.createElement("source");
source12.setAttribute("src", lenommeur);
audio12.appendChild(source12);
        break;
    case 15:
var audio13 = document.getElementById("audiojoa13");
var source13 = document.createElement("source");
source13.setAttribute("src", lenommeur);
audio13.appendChild(source13);
        break;
    case 16:
var audio14 = document.getElementById("audiojoa14");
var source14 = document.createElement("source");
source14.setAttribute("src", lenommeur);
audio14.appendChild(source14);
        break;

    default:
var audio15 = document.getElementById("audiojoa15");
var source15 = document.createElement("source");
source15.setAttribute("src", lenommeur);
audio15.appendChild(source15);
} 



}



function lecjoa1(FichierAudioJo)
{

 leraw = [];

var ludion = 32768, amplitude = 32768, nbdepoints = 5;

	function actiontotale(amplitude, nbdepoints, ludion)

	{

				var samples = 0, ote, ote1, reste, boucle;
			      var ideb, j, p, avec1, avec2, avec3;


/****debut front descend****/
		function frontdescend(amplitude, nbdepoints, ludion)
		{
				var ote1;

			      boucle = Math.round(nbdepoints *0.5);

			      reste = nbdepoints - boucle;

			      ote = Math.round( (ludion-amplitude)*0.5 );

				avec1 = boucle-1;
				p = table[avec1];

			function calcul1 (ludion, ote, ote1)
			{
			codebash = Math.round(ludion + ote1 - ote);
			

			 var volume = Math.floor(65535);
			monhexa = Math.floor(codebash -32767);
			  var total = leraw.push(app.utility.pack("v", monhexa));

			 }//fin calcul1


			for (ideb = boucle-1; ideb >= 0; ideb--) {
			ote1 = Math.floor((ote * 0.00001 * p[ideb]));
   			calcul1 (ludion, ote, ote1);
			}// fin frontdescend partie1 et fin for


/********deuxieme partie front descend****************/

			function sens2inverse(amplitude, nbdepoints, ludion)
			{
			var ote1;

			 boucle = Math.round(nbdepoints *0.5);
			 reste = nbdepoints - boucle;
			 ote = Math.round( (ludion-amplitude)*0.5 );

			avec1 = boucle-1;
			p = table[avec1];

			function calcul2 (ludion, ote, ote1)
			{
			codebash = Math.round(amplitude + ote - ote1);
			

			  var volume = Math.floor(65535);
			monhexa = Math.floor(codebash -32767);
			  var total = leraw.push(app.utility.pack("v", monhexa));

			 }// fin calcul2

			 for (ideb = 0; ideb < reste; ideb++) {
			 ote1 = Math.floor((ote * 0.00001 * p[ideb]));
   			 calcul2 (amplitude, ote, ote1);
			 } // fin du for

			 } // fin sens2inverse

			sens2inverse(amplitude, nbdepoints, ludion);		 

			ludion = amplitude
			return ludion;
			}// fin frontdescend

/********fin front descend *************************/


/****debut front montant*********************/
		function frontmontant(amplitude, nbdepoints, ludion)
		{
		ote = Math.round( (amplitude-ludion)*0.5 );			     
		 boucle = Math.round(nbdepoints * 0.5);
		reste = nbdepoints - boucle;
		
		var iee, j, p;
		avec1 = boucle-1;
		p = table[avec1];
		
			function calcul3 (ludion, ote, ote1)
			{
  			codebash = Math.round(ludion + ote - ote1);
			

			var volume = Math.floor(65535 );
			monhexa = Math.floor(codebash -32767);
			  var total = leraw.push(app.utility.pack("v", monhexa));

			}// fin calcul3



			for (ideb = boucle-1; ideb >= 0; ideb--) {
			ote1 = Math.floor(ote * 0.00001 * p[ideb]);
   			calcul3 (ludion, ote, ote1);
			}// fin premiere partie du fron et du for



				
			function sensinverse(amplitude, nbdepoints, ludion)
			{

			boucle = Math.round(nbdepoints * 0.5);
			reste = nbdepoints - boucle;
			ote = Math.round((amplitude-ludion)*0.5 );


			function calcul4 (ludion, ote, ote1)
			{
  			codebash = Math.round(ludion + ote + ote1);
			

			var volume = Math.floor(65535 );
			monhexa = Math.floor(codebash -32767);
			var total = leraw.push(app.utility.pack("v", monhexa));

			}// fin calcul4

/******/
				for (ideb = 0; ideb < reste; ideb++) {
				    ote1 = Math.round(ote * 0.00001 * p[ideb]);
   					calcul4 (ludion, ote, ote1);
				}
/********/






}

/* debut montant inverse du sens 1 */
sensinverse(amplitude, nbdepoints, ludion);

			ludion = amplitude
			return ludion;

			} //fin frontmontant





/****fin front montant***/







/*choix du sens du front*/

		  if (ludion > amplitude)
		    {
		 frontdescend(amplitude, nbdepoints, ludion);
		    }
		  else
		    {
		frontmontant(amplitude, nbdepoints, ludion);
		    }

/* fin choix du sens du front*/



}
/****fin action totale****/

for(var idejo= 0; idejo < FichierAudioJo.length; idejo++)
{//1

if (idejo/2 == Math.round(idejo/2)) {
	ludion = amplitude;
	amplitude = FichierAudioJo[idejo] * 256;
} else {//2
	nbdepoints = FichierAudioJo[idejo];
NbPtTotal += nbdepoints; /*44100 nbdepoints = 1 seconde*/
	actiontotale(amplitude, nbdepoints, ludion);




}//  fin du else de trie de récpération de données (amplitude et nbpoints)
}// fin de la boucle for de trie de récpération de données (amplitude et nbpoints)

genereLaFin();


return NbPtTotal;





}// fin fonction lecjoa1



/**************************premiere partie ouvre le fichier audio************************/




  

function lecjoadn() {
regarde();


var pas1; //variable du switch trie du nombre de fronts

var le1 = donne1;//variation amplitude front1
function maFonction1() {
var xx1 = le1 - donne5;
if ((donne5 > 0)&&(xx1 < donne6)){ xx1 = donne6;}//limit of the height variation
if ((donne5 < 0)&&(xx1 > donne6)){ xx1 = donne6;}//limit of the height variation
  return xx1;
}

var le2 = donne9;//variation amplitude front2
function maFonction2() {
var xx2 = le2 -(- donne13);
if ((donne13 > 0)&&(xx2 > donne14)){ xx2 = donne14;}//limit of the height variation
if ((donne13 < 0)&&(xx2 < donne14)){ xx2 = donne14;}//limit of the height variation
  return xx2;
}

var le3 = donne1;//plateau amplitude front1
function maFonction3() {
var xx3= le1 -1;
  return xx3;
}

var le4 = donne9;//plateau amplitude front2
function maFonction4() {
var xx4 = le2 -1;
  return xx4;
}

var le5 = donne2;//variation width front1
function maFonction5() {
var xx5 = le5 - donne7;
if ((donne7 > 0)&&(xx5 < donne8)){ xx5 = donne8;}//limit of the width variation
if ((donne7 < 0)&&(xx5 > donne8)){ xx5 = donne8;}//limit of the width variation
  return xx5;
}

var le6 = donne10;//variation width front2
function maFonction6() {
var xx6 = le6 - donne15;
if ((donne15 > 0)&&(xx6 < donne16)){ xx6 = donne16;}//limit of the width variation
if ((donne15 < 0)&&(xx6 > donne16)){ xx6 = donne16;}//limit of the width variation
  return xx6;
}


var le7 = donne18;//variation amplitude front3
function maFonction7() {
var xx7 = le7 - donne22;
if ((donne22 > 0)&&(xx7 < donne23)){ xx7 = donne23;}//limit of the height variation
if ((donne22 < 0)&&(xx7 > donne23)){ xx7 = donne23;}//limit of the height variation
  return xx7;
}

var le8 = donne27;//variation amplitude front4
function maFonction8() {
var xx8 = le8 - donne31;
if ((donne31 > 0)&&(xx8 > donne32)){ xx8 = donne32;}//limit of the height variation
if ((donne31 < 0)&&(xx8 < donne32)){ xx8 = donne32;}//limit of the height variation
  return xx8;
}

var le9 = donne36;//variation amplitude front5
function maFonction9() {
var xx9 = le9 - donne40;
if ((donne40 > 0)&&(xx9 < donne41)){ xx9 = donne41;}//limit of the height variation
if ((donne40 < 0)&&(xx9 > donne41)){ xx9 = donne41;}//limit of the height variation
  return xx9;
}

var le10 = donne45;//variation amplitude front6
function maFonction10() {
var xx10 = le10 - donne49;
if ((donne49 > 0)&&(xx10 > donne50)){ xx10 = donne50;}//limit of the height variation
if ((donne49 < 0)&&(xx10 < donne50)){ xx10 = donne50;}//limit of the height variation
  return xx10;
}

var le11 = donne18;//variation width front3
function maFonction11() {
var xx11 = le11 - donne24;
if ((donne24 > 0)&&(xx11 < donne25)){ xx11 = donne25;}//limit of the width variation
if ((donne24 < 0)&&(xx11 > donne25)){ xx11 = donne25;}//limit of the width variation
  return xx11;
}

var le12 = donne27;//variation width front4
function maFonction12() {
var xx12 = le12 - donne33;
if ((donne33 > 0)&&(xx12 < donne34)){ xx12 = donne34;}//limit of the width variation
if ((donne33 < 0)&&(xx12 > donne34)){ xx12 = donne34;}//limit of the width variation
  return xx12;
}

var le13 = donne36;//variation width front5
function maFonction13() {
var xx13 = le13 - donne42;
if ((donne42 > 0)&&(xx13 < donne43)){ xx13 = donne43;}//limit of the width variation
if ((donne42 < 0)&&(xx13 > donne43)){ xx13 = donne43;}//limit of the width variation
  return xx13;
}

var le14 = donne45;//variation width front6
function maFonction14() {
var xx14 = le14 - donne51;
if ((donne51 > 0)&&(xx14 < donne52)){ xx14 = donne52;}//limit of the width variation
if ((donne51 < 0)&&(xx14 > donne52)){ xx14 = donne52;}//limit of the width variation
  return xx14;
}

/*********************/



var nombi; //boucle generale de donne71
var nomba;
var nombd;
var nombe  = donne20;
nombe = (nombe < 1) ? 1:nombe;
var nombf;

var waxx2 = 128 - Number(donne54);
var waxx1 = (Number(donne54) -(- 128));
function maFonction7() {
var xx7 = waxx2 - donne58;
xx7 = (30 > xx7) ? 30 : xx7;
  return xx7;
}
function maFonction8() {
var xx8 = waxx1 -(- Number(donne58));
xx8 = (xx8 > 220) ? 220:xx8;
return xx8;
}

var laforce = donne3 -(- 1);

var letri1;
var letri2;
var letri3;
var letri4;
var letri5;
var letri6;
var letri7;
var letri8;

switch (Number(donne53)) {

  case 0 :


switch (Number(donne11)) {


//zone 2 fronts

 case 2 :
  for (nombi = 0; nombi < donne71; nombi++) {//1

   if ((donne5 != 0)&&(donne7 != 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) { //3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(le5);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) { //5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       } //5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(le6);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
    }//3 fin fo nomb
   le1 = maFonction1();
   le5 = maFonction5();
   le2 = maFonction2();
   le6 = maFonction6();
   }//2 fin if donne5 != 0 & donne7 != 0

   if ((donne5 != 0)&&(donne7 == 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) {//3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(donne2);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) {//5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       }//5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(donne10);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
     }//3 fin fo nomb
    le1 = maFonction1();
    le2 = maFonction2();
    }//2 fin if donne5 donne7

   if (donne5 == 0) {//2
    if (donne7 != 0) {//3
     for (var nomb = 0; nomb < laforce ; nomb++) {//4
      FichierAudioJo.push(donne1);
      FichierAudioJo.push(le5);
       if (donne72 > 0) {//5
        for (nomba = 0; nomba < donne72; nomba++) {//6
         FichierAudioJo.push(le3);
         FichierAudioJo.push(donne4);
         FichierAudioJo.push(donne1);
         FichierAudioJo.push(donne4);
         }//6 fin fo nomba
        }//5
       FichierAudioJo.push(donne9);
       FichierAudioJo.push(le6);
       if (donne73 > 0) {//5
	for (nombd = 0; nombd < donne73; nombd++) {//6
         FichierAudioJo.push(le4);
         FichierAudioJo.push(donne12);
         FichierAudioJo.push(donne9);
         FichierAudioJo.push(donne12);
         }//6 
        }//5
       }//4 fin fo nombd
      le5 = maFonction5();
      le6 = maFonction6();
      }//3 fin if donne7
     if (donne7 == 0) {//3
      for (var nomb = 0; nomb < laforce ; nomb++) {//4
       FichierAudioJo.push(donne1);
       FichierAudioJo.push(donne2);
        if (donne72 > 0) {//5
         for (nomba = 0; nomba < donne72; nomba++) {//6
          FichierAudioJo.push(le3);
          FichierAudioJo.push(donne4);
          FichierAudioJo.push(donne1);
          FichierAudioJo.push(donne4);
          }//6 fin fo nomba
         }//5
        FichierAudioJo.push(donne9);
        FichierAudioJo.push(donne10);
        if (donne73 > 0) {//5
         for (nombd = 0; nombd < donne73; nombd++) {//6
          FichierAudioJo.push(le4);
          FichierAudioJo.push(donne12);
          FichierAudioJo.push(donne9);
          FichierAudioJo.push(donne12);
	  }//6 
         }//5
        }//4 fin fo nombd
       }//3 fin else donne7
      }//2 fin else donne5
     }//1 fin du for donne71
    break;//fin donne11 == 2
//fin zone 2 fronts

//zone 3 fronts
  case 3 :

  for (nombi = 0; nombi < donne71; nombi++) {//1

   if ((donne5 != 0)&&(donne7 != 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) { //3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(le5);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) { //5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       } //5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(le6);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
    }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   le1 = maFonction1();
   le5 = maFonction5();
   le2 = maFonction2();
   le6 = maFonction6();
   le7 = maFonction7();
   le11 = maFonction11();
   }//2 fin if donne5 != 0 & donne7 != 0

   if ((donne5 != 0)&&(donne7 == 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) {//3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(donne2);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) {//5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       }//5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(donne10);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
     }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
    le1 = maFonction1();
    le2 = maFonction2();
    le7 = maFonction7();
    le11 = maFonction11();
    }//2 fin if donne5 donne7

   if (donne5 == 0) {//2
    if (donne7 != 0) {//3
     for (var nomb = 0; nomb < laforce ; nomb++) {//4
      FichierAudioJo.push(donne1);
      FichierAudioJo.push(le5);
       if (donne72 > 0) {//5
        for (nomba = 0; nomba < donne72; nomba++) {//6
         FichierAudioJo.push(le3);
         FichierAudioJo.push(donne4);
         FichierAudioJo.push(donne1);
         FichierAudioJo.push(donne4);
         }//6 fin fo nomba
        }//5
       FichierAudioJo.push(donne9);
       FichierAudioJo.push(le6);
       if (donne73 > 0) {//5
	for (nombd = 0; nombd < donne73; nombd++) {//6
         FichierAudioJo.push(le4);
         FichierAudioJo.push(donne12);
         FichierAudioJo.push(donne9);
         FichierAudioJo.push(donne12);
         }//6 
        }//5
       }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
      le5 = maFonction5();
      le6 = maFonction6();
      le7 = maFonction7();
      le11 = maFonction11();
      }//3 fin if donne7
     if (donne7 == 0) {//3
      for (var nomb = 0; nomb < laforce ; nomb++) {//4
       FichierAudioJo.push(donne1);
       FichierAudioJo.push(donne2);
        if (donne72 > 0) {//5
         for (nomba = 0; nomba < donne72; nomba++) {//6
          FichierAudioJo.push(le3);
          FichierAudioJo.push(donne4);
          FichierAudioJo.push(donne1);
          FichierAudioJo.push(donne4);
          }//6 fin fo nomba
         }//5
        FichierAudioJo.push(donne9);
        FichierAudioJo.push(donne10);
        if (donne73 > 0) {//5
         for (nombd = 0; nombd < donne73; nombd++) {//6
          FichierAudioJo.push(le4);
          FichierAudioJo.push(donne12);
          FichierAudioJo.push(donne9);
          FichierAudioJo.push(donne12);
	  }//6 
         }//5
        }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
      le7 = maFonction7();
      le11 = maFonction11();
       }//3 fin else donne7
      }//2 fin else donne5
     }//1 fin du for donne71

        break;//fin donne11 == 3

//fin zone 3 fronts

//zone 4 fronts

  case 4 :// donne11
  for (nombi = 0; nombi < donne71; nombi++) {//1

   if ((donne5 != 0)&&(donne7 != 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) { //3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(le5);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) { //5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       } //5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(le6);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
    }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   le1 = maFonction1();
   le5 = maFonction5();
   le2 = maFonction2();
   le6 = maFonction6();
   le7 = maFonction7();
   le8 = maFonction8();
   le11 = maFonction11();
   le12 = maFonction12();
   }//2 fin if donne5 != 0 & donne7 != 0

   if ((donne5 != 0)&&(donne7 == 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) {//3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(donne2);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) {//5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       }//5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(donne10);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
     }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
    le1 = maFonction1();
    le2 = maFonction2();
    le7 = maFonction7();
    le8 = maFonction8();
    le11 = maFonction11();
    le12 = maFonction12();
    }//2 fin if donne5 donne7

   if (donne5 == 0) {//2
    if (donne7 != 0) {//3
     for (var nomb = 0; nomb < laforce ; nomb++) {//4
      FichierAudioJo.push(donne1);
      FichierAudioJo.push(le5);
       if (donne72 > 0) {//5
        for (nomba = 0; nomba < donne72; nomba++) {//6
         FichierAudioJo.push(le3);
         FichierAudioJo.push(donne4);
         FichierAudioJo.push(donne1);
         FichierAudioJo.push(donne4);
         }//6 fin fo nomba
        }//5
       FichierAudioJo.push(donne9);
       FichierAudioJo.push(le6);
       if (donne73 > 0) {//5
	for (nombd = 0; nombd < donne73; nombd++) {//6
         FichierAudioJo.push(le4);
         FichierAudioJo.push(donne12);
         FichierAudioJo.push(donne9);
         FichierAudioJo.push(donne12);
         }//6 
        }//5
       }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
      le5 = maFonction5();
      le6 = maFonction6();
      le7 = maFonction7();
      le8 = maFonction8();
      le11 = maFonction11();
      le12 = maFonction12();
      }//3 fin if donne7
     if (donne7 == 0) {//3
      for (var nomb = 0; nomb < laforce ; nomb++) {//4
       FichierAudioJo.push(donne1);
       FichierAudioJo.push(donne2);
        if (donne72 > 0) {//5
         for (nomba = 0; nomba < donne72; nomba++) {//6
          FichierAudioJo.push(le3);
          FichierAudioJo.push(donne4);
          FichierAudioJo.push(donne1);
          FichierAudioJo.push(donne4);
          }//6 fin fo nomba
         }//5
        FichierAudioJo.push(donne9);
        FichierAudioJo.push(donne10);
        if (donne73 > 0) {//5
         for (nombd = 0; nombd < donne73; nombd++) {//6
          FichierAudioJo.push(le4);
          FichierAudioJo.push(donne12);
          FichierAudioJo.push(donne9);
          FichierAudioJo.push(donne12);
	  }//6 
         }//5
        }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
      le7 = maFonction7();
      le8 = maFonction8();
      le11 = maFonction11();
      le12 = maFonction12();
       }//3 fin else donne7
      }//2 fin else donne5
     }//1 fin du for donne71
        break;//fin donne11 == 4

//fin zone 4 fronts

//zone 5 fronts

  case 5 :// donne11

  for (nombi = 0; nombi < donne71; nombi++) {//1

   if ((donne5 != 0)&&(donne7 != 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) { //3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(le5);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) { //5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       } //5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(le6);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
    }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
   le1 = maFonction1();
   le5 = maFonction5();
   le2 = maFonction2();
   le6 = maFonction6();
   le7 = maFonction7();
   le8 = maFonction8();
   le9 = maFonction9();
   le11 = maFonction11();
   le12 = maFonction12();
   le13 = maFonction13();
   }//2 fin if donne5 != 0 & donne7 != 0

   if ((donne5 != 0)&&(donne7 == 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) {//3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(donne2);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) {//5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       }//5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(donne10);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
     }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
    le1 = maFonction1();
    le2 = maFonction2();
    le7 = maFonction7();
    le8 = maFonction8();
   le9 = maFonction9();
   le11 = maFonction11();
   le12 = maFonction12();
   le13 = maFonction13();
    }//2 fin if donne5 donne7

   if (donne5 == 0) {//2
    if (donne7 != 0) {//3
     for (var nomb = 0; nomb < laforce ; nomb++) {//4
      FichierAudioJo.push(donne1);
      FichierAudioJo.push(le5);
       if (donne72 > 0) {//5
        for (nomba = 0; nomba < donne72; nomba++) {//6
         FichierAudioJo.push(le3);
         FichierAudioJo.push(donne4);
         FichierAudioJo.push(donne1);
         FichierAudioJo.push(donne4);
         }//6 fin fo nomba
        }//5
       FichierAudioJo.push(donne9);
       FichierAudioJo.push(le6);
       if (donne73 > 0) {//5
	for (nombd = 0; nombd < donne73; nombd++) {//6
         FichierAudioJo.push(le4);
         FichierAudioJo.push(donne12);
         FichierAudioJo.push(donne9);
         FichierAudioJo.push(donne12);
         }//6 
        }//5
       }//4 fin fo nombd
    le1 = maFonction1();
    le2 = maFonction2();
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
      le5 = maFonction5();
      le6 = maFonction6();
      le9 = maFonction9();
      le13 = maFonction13();
      }//3 fin if donne7
     if (donne7 == 0) {//3
      for (var nomb = 0; nomb < laforce ; nomb++) {//4
       FichierAudioJo.push(donne1);
       FichierAudioJo.push(donne2);
        if (donne72 > 0) {//5
         for (nomba = 0; nomba < donne72; nomba++) {//6
          FichierAudioJo.push(le3);
          FichierAudioJo.push(donne4);
          FichierAudioJo.push(donne1);
          FichierAudioJo.push(donne4);
          }//6 fin fo nomba
         }//5
        FichierAudioJo.push(donne9);
        FichierAudioJo.push(donne10);
        if (donne73 > 0) {//5
         for (nombd = 0; nombd < donne73; nombd++) {//6
          FichierAudioJo.push(le4);
          FichierAudioJo.push(donne12);
          FichierAudioJo.push(donne9);
          FichierAudioJo.push(donne12);
	  }//6 
         }//5
        }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
       le7 = maFonction7();
       le8 = maFonction8();
       le9 = maFonction9();
       le11 = maFonction11();
       le12 = maFonction12();
       le13 = maFonction13();
       }//3 fin else donne7
      }//2 fin else donne5
     }//1 fin du for donne71

        break;//fin donne11 == 5

//fin zone 5 fronts

//zone 6 fronts

  case 6 :// donne11
  for (nombi = 0; nombi < donne71; nombi++) {//1

   if ((donne5 != 0)&&(donne7 != 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) { //3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(le5);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) { //5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       } //5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(le6);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
    }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
   letri4 = donne49 == 0 ? donne45 : le10;
   FichierAudioJo.push(letri4); //front6
   letri8 = donne51 == 0 ? donne46 : le14;
   FichierAudioJo.push(letri8); //front6
   le1 = maFonction1();
   le5 = maFonction5();
   le2 = maFonction2();
   le6 = maFonction6();
   le7 = maFonction7();
   le8 = maFonction8();
   le9 = maFonction9();
   le10 = maFonction10();
   le11 = maFonction11();
   le12 = maFonction12();
   le13 = maFonction13();
   le14 = maFonction14();
   }//2 fin if donne5 != 0 & donne7 != 0

   if ((donne5 != 0)&&(donne7 == 0)) {//2
    le3 = maFonction3();
    le4 = maFonction4();
    for (var nomb = 0; nomb < laforce ; nomb++) {//3 height repeat
     FichierAudioJo.push(le1);
     FichierAudioJo.push(donne2);
     if (donne72 > 0) {//4
      for (nomba = 0; nomba < donne72; nomba++) {//5 number of stays in place
       FichierAudioJo.push(le3);
       FichierAudioJo.push(donne4);
       FichierAudioJo.push(le1);
       FichierAudioJo.push(donne4);
       }//5 fin fo nomba
      }//4

     FichierAudioJo.push(le2);
     FichierAudioJo.push(donne10);
     if (donne73 > 0) {//4
      for (nombd = 0; nombd < donne73; nombd++) {//5 number of stays in place
       FichierAudioJo.push(le4);
       FichierAudioJo.push(donne12);
       FichierAudioJo.push(le2);
       FichierAudioJo.push(donne12);
       }//5 
      }//4
     }//3 fin fo nomb
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
   letri4 = donne49 == 0 ? donne45 : le10;
   FichierAudioJo.push(letri4); //front6
   letri8 = donne51 == 0 ? donne46 : le14;
   FichierAudioJo.push(letri8); //front6
    le1 = maFonction1();
    le2 = maFonction2();
    le7 = maFonction7();
    le8 = maFonction8();
    le9 = maFonction9();
    le10 = maFonction10();
    le11 = maFonction11();
    le12 = maFonction12();
    le13 = maFonction13();
    le14 = maFonction14();
    }//2 fin if donne5 donne7

   if (donne5 == 0) {//2
    if (donne7 != 0) {//3
     for (var nomb = 0; nomb < laforce ; nomb++) {//4
      FichierAudioJo.push(donne1);
      FichierAudioJo.push(le5);
       if (donne72 > 0) {//5
        for (nomba = 0; nomba < donne72; nomba++) {//6
         FichierAudioJo.push(le3);
         FichierAudioJo.push(donne4);
         FichierAudioJo.push(donne1);
         FichierAudioJo.push(donne4);
         }//6 fin fo nomba
        }//5
       FichierAudioJo.push(donne9);
       FichierAudioJo.push(le6);
       if (donne73 > 0) {//5
	for (nombd = 0; nombd < donne73; nombd++) {//6
         FichierAudioJo.push(le4);
         FichierAudioJo.push(donne12);
         FichierAudioJo.push(donne9);
         FichierAudioJo.push(donne12);
         }//6 
        }//5
       }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
   letri4 = donne49 == 0 ? donne45 : le10;
   FichierAudioJo.push(letri4); //front6
   letri8 = donne51 == 0 ? donne46 : le14;
   FichierAudioJo.push(letri8); //front6
      le5 = maFonction5();
      le6 = maFonction6();
      le7 = maFonction7();
      le8 = maFonction8();
      le9 = maFonction9();
      le10 = maFonction10();
      le11 = maFonction11();
      le12 = maFonction12();
      le13 = maFonction13();
      le14 = maFonction14();
      }//3 fin if donne7
     if (donne7 == 0) {//3
      for (var nomb = 0; nomb < laforce ; nomb++) {//4
       FichierAudioJo.push(donne1);
       FichierAudioJo.push(donne2);
        if (donne72 > 0) {//5
         for (nomba = 0; nomba < donne72; nomba++) {//6
          FichierAudioJo.push(le3);
          FichierAudioJo.push(donne4);
          FichierAudioJo.push(donne1);
          FichierAudioJo.push(donne4);
          }//6 fin fo nomba
         }//5
        FichierAudioJo.push(donne9);
        FichierAudioJo.push(donne10);
        if (donne73 > 0) {//5
         for (nombd = 0; nombd < donne73; nombd++) {//6
          FichierAudioJo.push(le4);
          FichierAudioJo.push(donne12);
          FichierAudioJo.push(donne9);
          FichierAudioJo.push(donne12);
	  }//6 
         }//5
        }//4 fin fo nombd
   letri1 = donne22 == 0 ? donne18 : le7;
   FichierAudioJo.push(letri1); //front3
   letri5 = donne24 == 0 ? donne19 : le11;
   FichierAudioJo.push(letri5); //front3
   letri2 = donne31 == 0 ? donne27 : le8;
   FichierAudioJo.push(letri2); //front4
   letri6 = donne33 == 0 ? donne28 : le12;
   FichierAudioJo.push(letri6); //front4
   letri3 = donne40 == 0 ? donne36 : le9;
   FichierAudioJo.push(letri3); //front5
   letri7 = donne42 == 0 ? donne37 : le13;
   FichierAudioJo.push(letri7); //front5
   letri4 = donne49 == 0 ? donne45 : le10;
   FichierAudioJo.push(letri4); //front6
   letri8 = donne51 == 0 ? donne46 : le14;
   FichierAudioJo.push(letri8); //front6
      le7 = maFonction7();
      le8 = maFonction8();
      le9 = maFonction9();
      le10 = maFonction10();
      le11 = maFonction11();
      le12 = maFonction12();
      le13 = maFonction13();
      le14 = maFonction14();
       }//3 fin else donne7
      }//2 fin else donne5
     }//1 fin du for donne71
        break;	//fin zone 6 fronts			
}//fin switch donne11 

        break;	//donne53 = 0	

  case 1 :// donne53 = 1

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne55);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne55);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne55);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne55);


} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne55);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne55);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne55);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne55);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 1

/*****************************************/

  case 2 :// donne53 = 2

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);


} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 2
/*****************************************/

  case 3 :// donne53 = 3

FichierAudioJo.push(Number(donne54) -(- 128)); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);


} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 3
/*****************************************/

  case 4 :// donne53 = 4

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);


} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne1);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 4

/*****************************************/

  case 5 :// donne53 = 5

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);


} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 5

/*****************************************/

  case 6 :// donne53 = 6

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);

} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);

} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59


} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 6

/*****************************************/

  case 7 :// donne53 = 7

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);

} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59


} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 7

/*****************************************/

  case 8 :// donne53 = 8

FichierAudioJo.push(Number(donne54) -(- 128));
FichierAudioJo.push(donne2);
FichierAudioJo.push(128 - donne54); 
FichierAudioJo.push(donne10);

if(donne56 == 0){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);

} // fin for nombi
} // fin if donne56 == 0

if((donne56 > 0)&&(donne57==0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0

if((donne56 > 0)&&(donne57 > 0)){

for (nombi = 0; nombi < donne71; nombi++) {

waxx1 = maFonction8();
waxx2 = maFonction7();

for (var nombia = 0; nombia < donne56; nombia++) {

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne37);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne28);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne19);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59

for (var nombiab = 0; nombiab < donne59; nombiab ++) {
FichierAudioJo.push(waxx1); 
FichierAudioJo.push(donne10);
FichierAudioJo.push(waxx1-1); 
FichierAudioJo.push(donne57);
} // fin for donne59
for (var nombiab = 0; nombiab < donne59; nombiab++) {
FichierAudioJo.push(waxx2); 
FichierAudioJo.push(donne2);
FichierAudioJo.push(waxx2-1); 
FichierAudioJo.push(donne57);
} // fin for donne59


} // fin for donne56


} // fin for nombi
} // fin if donne56 > 0


        break;	//donne53 = 8

}//fin switch  donne53



//}// fin de la boucle du nombre de sons différents


FichierAudioJo = FichierAudioJo.map(Number);
lecjoa1(FichierAudioJo);

    }
/****************************fin premier niveau qui ouvre le fichier*****************************************************/



/**passerelle firefox 48 pour remplacer le bouton d'appel js**/
   function load() { 
     var el = document.getElementById("tet1"); 
     el.addEventListener("click", lecjoadn, false); 
   } 


 document.addEventListener("DOMContentLoaded", function(event) {
    load();
  });
/**fin passerelle firefox 48**/

