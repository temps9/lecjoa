    	 var mua1 = 0;
    	 var mua2 = 0;
    	 var mua3 = 0;
    	 var mua4 = 0;
    	 var mua5 = 0;
    	 var mua6 = 0;
    	 var mua7 = 0;
    	 var mua8 = 0;
    	 var mua9 = 0;
    	 var mua10 = 0;
    	 var mua11 = 0;
    	 var mua12 = 0;
    	 var mua13 = 0;
    	 var mua14 = 0;
    	 var mua15 = 0;
    	 var mua16 = 0;
    	 var mua17 = 0;
    	 var mua18 = 0;
    	 var mua19 = 0;
    	 var mua20 = 0;
    	 var mua21 = 0;
    	 var mua22 = 0;
    	 var mua23 = 0;
    	 var mua24 = 0;
    	 var mua25 = 0;
    	 var mua26 = 0;
    	 var mua27 = 0;
    	 var mua28 = 0;
    	 var mua29 = 0;
    	 var mua30 = 0;
    	 var mua31 = 0;
    	 var mua32 = 0;
    	 var mua33 = 0;
    	 var mua34 = 0;
    	 var mua35 = 0;
    	 var mua36 = 0;
    	 var mua37 = 0;
    	 var mua38 = 0;
    	 var mua39 = 0;
    	 var mua40 = 0;
    	 var mua41 = 0;
    	 var mua42 = 0;
    	 var mua43 = 0;
    	 var mua44 = 0;
    	 var mua45 = 0;
    	 var mua46 = 0;
    	 var mua47 = 0;
    	 var mua48 = 0;
    	 var mua49 = 0;


function multitouchea(mua1){
    switch(mua1) {
    case 0:
  var multia1 = document.getElementById("1wav");
  multia1.play();
        break;
    case 1:
  var multia2 = document.getElementById("1awav");
  multia2.play();
        break;
    case 2:
  var multia3 = document.getElementById("1bwav");
  multia3.play();
        break;
    default:
  var multia4 = document.getElementById("1cwav");
  multia4.play();
  }}


function multitouchez(mua2){
    switch(mua2) {
    case 0:
  var multiz1 = document.getElementById("2wav");
  multiz1.play();
        break;
    case 1:
  var multiz2 = document.getElementById("2awav");
  multiz2.play();
        break;
    case 2:
  var multiz3 = document.getElementById("2bwav");
  multiz3.play();
        break;
    default:
  var multia4 = document.getElementById("2cwav");
  multia4.play();
  }}
function multitouchee(mua3){
    switch(mua3) {
    case 0:
  var multie1 = document.getElementById("3wav");
  multie1.play();
        break;
    case 1:
  var multie2 = document.getElementById("3awav");
  multie2.play();
        break;
    case 2:
  var multie3 = document.getElementById("3bwav");
  multie3.play();
        break;
    default:
  var multie4 = document.getElementById("3cwav");
  multie4.play();
  }} 
function multitoucher(mua4){
    switch(mua4) {
    case 0:
  var multir1 = document.getElementById("4wav");
  multir1.play();
        break;
    case 1:
  var multir2 = document.getElementById("4awav");
  multir2.play();
        break;
    case 2:
  var multir3 = document.getElementById("4bwav");
  multir3.play();
        break;
    default:
  var multir4 = document.getElementById("4cwav");
  multir4.play();
  }} 
function multitouchet(mua5){
    switch(mua5) {
    case 0:
  var multit1 = document.getElementById("5wav");
  multit1.play();
        break;
    case 1:
  var multit2 = document.getElementById("5awav");
  multit2.play();
        break;
    case 2:
  var multit3 = document.getElementById("5bwav");
  multit3.play();
        break;
    default:
  var multit4 = document.getElementById("5cwav");
  multit4.play();
  }}
function multitouchey(mua6){
    switch(mua6) {
    case 0:
  var multiy1 = document.getElementById("6wav");
  multiy1.play();
        break;
    case 1:
  var multiy2 = document.getElementById("6awav");
  multiy2.play();
        break;
    case 2:
  var multiy3 = document.getElementById("6bwav");
  multiy3.play();
        break;
    default:
  var multiy4 = document.getElementById("6cwav");
  multiy4.play();
  }} 
function multitoucheu(mua7){
    switch(mua7) {
    case 0:
  var multiu1 = document.getElementById("7wav");
  multiu1.play();
        break;
    case 1:
  var multiu2 = document.getElementById("7awav");
  multiu2.play();
        break;
    case 2:
  var multiu3 = document.getElementById("7bwav");
  multiu3.play();
        break;
    default:
  var multiu4 = document.getElementById("7cwav");
  multiu4.play();
  }}
function multitouchei(mua8){
    switch(mua8) {
    case 0:
  var multii1 = document.getElementById("8wav");
  multii1.play();
        break;
    case 1:
  var multii2 = document.getElementById("8awav");
  multii2.play();
        break;
    case 2:
  var multii3 = document.getElementById("8bwav");
  multii3.play();
        break;
    default:
  var multii4 = document.getElementById("8cwav");
  multii4.play();
  }}
function multitoucheo(mua9){
    switch(mua9) {
    case 0:
  var multio1 = document.getElementById("9wav");
  multio1.play();
        break;
    case 1:
  var multio2 = document.getElementById("9awav");
  multio2.play();
        break;
    case 2:
  var multio3 = document.getElementById("9bwav");
  multio3.play();
        break;
    default:
  var multio4 = document.getElementById("9cwav");
  multio4.play();
  }}
function multitouchep(mua10){
    switch(mua10) {
    case 0:
  var multip1 = document.getElementById("10wav");
  multip1.play();
        break;
    case 1:
  var multip2 = document.getElementById("10awav");
  multip2.play();
        break;
    case 2:
  var multip3 = document.getElementById("10bwav");
  multip3.play();
        break;
    default:
  var multip4 = document.getElementById("10cwav");
  multip4.play();
  }}
 function multitoucheq(mua11){
    switch(mua11) {
    case 0:
  var multiq1 = document.getElementById("11wav");
  multiq1.play();
        break;
    case 1:
  var multiq2 = document.getElementById("11awav");
  multiq2.play();
        break;
    case 2:
  var multiq3 = document.getElementById("11bwav");
  multiq3.play();
        break;
    default:
  var multiq4 = document.getElementById("11cwav");
  multiq4.play();
  }}
function multitouches(mua12){
    switch(mua12) {
    case 0:
  var multis1 = document.getElementById("12wav");
  multis1.play();
        break;
    case 1:
  var multis2 = document.getElementById("12awav");
  multis2.play();
        break;
    case 2:
  var multis3 = document.getElementById("12bwav");
  multis3.play();
        break;
    default:
  var multis4 = document.getElementById("12cwav");
  multis4.play();
  }}
function multitouched(mua13){
    switch(mua13) {
    case 0:
  var multid1 = document.getElementById("13wav");
  multid1.play();
        break;
    case 1:
  var multid2 = document.getElementById("13awav");
  multid2.play();
        break;
    case 2:
  var multid3 = document.getElementById("13bwav");
  multid3.play();
        break;
    default:
  var multid4 = document.getElementById("13cwav");
  multid4.play();
  }}
function multitouchef(mua14){
    switch(mua14) {
    case 0:
  var multif1 = document.getElementById("14wav");
  multif1.play();
        break;
    case 1:
  var multif2 = document.getElementById("14awav");
  multif2.play();
        break;
    case 2:
  var multif3 = document.getElementById("14bwav");
  multif3.play();
        break;
    default:
  var multif4 = document.getElementById("14cwav");
  multif4.play();
  }}
function multitoucheg(mua15){
    switch(mua15) {
    case 0:
  var multig1 = document.getElementById("15wav");
  multig1.play();
        break;
    case 1:
  var multig2 = document.getElementById("15awav");
  multig2.play();
        break;
    case 2:
  var multig3 = document.getElementById("15bwav");
  multig3.play();
        break;
    default:
  var multig4 = document.getElementById("15cwav");
  multig4.play();
  }}
function multitoucheh(mua16){
    switch(mua16) {
    case 0:
  var multih1 = document.getElementById("16wav");
  multih1.play();
        break;
    case 1:
  var multih2 = document.getElementById("16awav");
  multih2.play();
        break;
    case 2:
  var multih3 = document.getElementById("16bwav");
  multih3.play();
        break;
    default:
  var multih4 = document.getElementById("16cwav");
  multih4.play();
  }}
function multitouchej(mua17){
    switch(mua17) {
    case 0:
  var multij1 = document.getElementById("17wav");
  multij1.play();
        break;
    case 1:
  var multij2 = document.getElementById("17awav");
  multij2.play();
        break;
    case 2:
  var multij3 = document.getElementById("17bwav");
  multij3.play();
        break;
    default:
  var multij4 = document.getElementById("17cwav");
  multij4.play();
  }}
function multitouchek(mua18){
    switch(mua18) {
    case 0:
  var multik1 = document.getElementById("18wav");
  multik1.play();
        break;
    case 1:
  var multik2 = document.getElementById("18awav");
  multik2.play();
        break;
    case 2:
  var multik3 = document.getElementById("18bwav");
  multik3.play();
        break;
    default:
  var multik4 = document.getElementById("18cwav");
  multik4.play();
  }}
function multitouchel(mua19){
    switch(mua19) {
    case 0:
  var multil1 = document.getElementById("19wav");
  multil1.play();
        break;
    case 1:
  var multil2 = document.getElementById("19awav");
  multil2.play();
        break;
    case 2:
  var multil3 = document.getElementById("19bwav");
  multil3.play();
        break;
    default:
  var multil4 = document.getElementById("19cwav");
  multil4.play();
  }}
function multitouchem(mua20){
    switch(mua20) {
    case 0:
  var multim1 = document.getElementById("20wav");
  multim1.play();
        break;
    case 1:
  var multim2 = document.getElementById("20awav");
  multim2.play();
        break;
    case 2:
  var multim3 = document.getElementById("20bwav");
  multim3.play();
        break;
    default:
  var multim4 = document.getElementById("20cwav");
  multim4.play();
  }}
function multitouchew(mua21){
    switch(mua21) {
    case 0:
  var multiw1 = document.getElementById("21wav");
  multiw1.play();
        break;
    case 1:
  var multiw2 = document.getElementById("21awav");
  multiw2.play();
        break;
    case 2:
  var multiw3 = document.getElementById("21bwav");
  multiw3.play();
        break;
    default:
  var multiw4 = document.getElementById("21cwav");
  multiw4.play();
  }}
function multitouchex(mua22){
    switch(mua22) {
    case 0:
  var multix1 = document.getElementById("22wav");
  multix1.play();
        break;
    case 1:
  var multix2 = document.getElementById("22awav");
  multix2.play();
        break;
    case 2:
  var multix3 = document.getElementById("22bwav");
  multix3.play();
        break;
    default:
  var multix4 = document.getElementById("22cwav");
  multix4.play();
  }}
function multitouchec(mua23){
    switch(mua23) {
    case 0:
  var multic1 = document.getElementById("23wav");
  multic1.play();
        break;
    case 1:
  var multic2 = document.getElementById("23awav");
  multic2.play();
        break;
    case 2:
  var multic3 = document.getElementById("23bwav");
  multic3.play();
        break;
    default:
  var multic4 = document.getElementById("23cwav");
  multic4.play();
  }}
function multitouchev(mua24){
    switch(mua24) {
    case 0:
  var multiv1 = document.getElementById("24wav");
  multiv1.play();
        break;
    case 1:
  var multiv2 = document.getElementById("24awav");
  multiv2.play();
        break;
    case 2:
  var multiv3 = document.getElementById("24bwav");
  multiv3.play();
        break;
    default:
  var multiv4 = document.getElementById("24cwav");
  multiv4.play();
  }}
function multitoucheb(mua25){
    switch(mua25) {
    case 0:
  var multib1 = document.getElementById("25wav");
  multib1.play();
        break;
    case 1:
  var multib2 = document.getElementById("25awav");
  multib2.play();
        break;
    case 2:
  var multib3 = document.getElementById("25bwav");
  multib3.play();
        break;
    default:
  var multib4 = document.getElementById("25cwav");
  multib4.play();
  }}
function multitouchen(mua26){
    switch(mua26) {
    case 0:
  var multin1 = document.getElementById("26wav");
  multin1.play();
        break;
    case 1:
  var multin2 = document.getElementById("26awav");
  multin2.play();
        break;
    case 2:
  var multin3 = document.getElementById("26bwav");
  multin3.play();
        break;
    default:
  var multin4 = document.getElementById("26cwav");
  multin4.play();
  }}
function multitoucheno(mua27){
    switch(mua27) {
    case 0:
  var multioo1 = document.getElementById("27wav");
  multioo1.play();
        break;
    case 1:
  var multioo2 = document.getElementById("27awav");
  multioo2.play();
        break;
    case 2:
  var multioo3 = document.getElementById("27bwav");
  multioo3.play();
        break;
    default:
  var multioo4 = document.getElementById("27cwav");
  multioo4.play();
  }}
 function multitouche1(mua28){
    switch(mua28) {
    case 0:
  var multi11 = document.getElementById("28wav");
  multi11.play();
        break;
    case 1:
  var multi12 = document.getElementById("28awav");
  multi12.play();
        break;
    case 2:
  var multi13 = document.getElementById("28bwav");
  multi13.play();
        break;
    default:
  var multi14 = document.getElementById("28cwav");
  multi14.play();
  }}
function multitouche2(mua29){
    switch(mua29) {
    case 0:
  var multi21 = document.getElementById("29wav");
  multi21.play();
        break;
    case 1:
  var multi22 = document.getElementById("29awav");
  multi22.play();
        break;
    case 2:
  var multi23 = document.getElementById("29bwav");
  multi23.play();
        break;
    default:
  var multi24 = document.getElementById("29cwav");
  multi24.play();
  }}
function multitouche3(mua30){
    switch(mua30) {
    case 0:
  var multi31 = document.getElementById("30wav");
  multi31.play();
        break;
    case 1:
  var multi32 = document.getElementById("30awav");
  multi32.play();
        break;
    case 2:
  var multi33 = document.getElementById("30bwav");
  multi33.play();
        break;
    default:
  var multi34 = document.getElementById("30cwav");
  multi34.play();
  }}
function multitouche4(mua31){
    switch(mua31) {
    case 0:
  var multi41 = document.getElementById("31wav");
  multi41.play();
        break;
    case 1:
  var multi42 = document.getElementById("31awav");
  multi42.play();
        break;
    case 2:
  var multi43 = document.getElementById("31bwav");
  multi43.play();
        break;
    default:
  var multi44 = document.getElementById("31cwav");
  multi44.play();
  }}
function multitouche5(mua32){
    switch(mua32) {
    case 0:
  var multi51 = document.getElementById("32wav");
  multi51.play();
        break;
    case 1:
  var multi52 = document.getElementById("32awav");
  multi52.play();
        break;
    case 2:
  var multi53 = document.getElementById("32bwav");
  multi53.play();
        break;
    default:
  var multi54 = document.getElementById("32cwav");
  multi54.play();
  }}
function multitouche6(mua33){
    switch(mua33) {
    case 0:
  var multi61 = document.getElementById("33wav");
  multi61.play();
        break;
    case 1:
  var multi62 = document.getElementById("33awav");
  multi62.play();
        break;
    case 2:
  var multi63 = document.getElementById("33bwav");
  multi63.play();
        break;
    default:
  var multi64 = document.getElementById("33cwav");
  multi64.play();
  }}
function multitouche7(mua34){
    switch(mua34) {
    case 0:
  var multi71 = document.getElementById("34wav");
  multi71.play();
        break;
    case 1:
  var multi72 = document.getElementById("34awav");
  multi72.play();
        break;
    case 2:
  var multi73 = document.getElementById("34bwav");
  multi73.play();
        break;
    default:
  var multi74 = document.getElementById("34cwav");
  multi74.play();
  }}
function multitouche8(mua35){
    switch(mua35) {
    case 0:
  var multi81 = document.getElementById("35wav");
  multi81.play();
        break;
    case 1:
  var multi82 = document.getElementById("35awav");
  multi82.play();
        break;
    case 2:
  var multi83 = document.getElementById("35bwav");
  multi83.play();
        break;
    default:
  var multi84 = document.getElementById("35cwav");
  multi84.play();
  }}
function multitouche9(mua36){
    switch(mua36) {
    case 0:
  var multi91 = document.getElementById("36wav");
  multi91.play();
        break;
    case 1:
  var multi92 = document.getElementById("36awav");
  multi92.play();
        break;
    case 2:
  var multi93 = document.getElementById("36bwav");
  multi93.play();
        break;
    default:
  var multi94 = document.getElementById("36cwav");
  multi94.play();
  }}
function multitouchess1a(mua37){
    switch(mua37) {
    case 0:
  var multiss1a = document.getElementById("37wav");
  multiss1a.play();
        break;
    case 1:
  var multiss1b = document.getElementById("37awav");
  multiss1b.play();
        break;
    case 2:
  var multiss1c = document.getElementById("37bwav");
  multiss1c.play();
        break;
    default:
  var multiss1d = document.getElementById("37cwav");
  multiss1d.play();
  }}
function multitouchess2a(mua38){
    switch(mua38) {
    case 0:
  var multiss2a = document.getElementById("38wav");
  multiss2a.play();
        break;
    case 1:
  var multiss2b = document.getElementById("38awav");
  multiss2b.play();
        break;
    case 2:
  var multiss2c = document.getElementById("38bwav");
  multiss2c.play();
        break;
    default:
  var multiss2d = document.getElementById("38cwav");
  multiss2d.play();
  }}

function multitouchess3a(mua39){
    switch(mua39) {
    case 0:
  var multiss3a = document.getElementById("39wav");
  multiss3a.play();
        break;
    case 1:
  var multiss3b = document.getElementById("39awav");
  multiss3b.play();
        break;
    case 2:
  var multiss3c = document.getElementById("39bwav");
  multiss3c.play();
        break;
    default:
  var multiss3d = document.getElementById("39cwav");
  multiss3d.play();
  }}

function multitouchess4a(mua40){
    switch(mua40) {
    case 0:
  var multiss4a = document.getElementById("40wav");
  multiss4a.play();
        break;
    case 1:
  var multiss4b = document.getElementById("40awav");
  multiss4b.play();
        break;
    case 2:
  var multiss4c = document.getElementById("40bwav");
  multiss4c.play();
        break;
    default:
  var multiss4d = document.getElementById("40cwav");
  multiss4d.play();
  }}

function multitouchess5a(mua41){
    switch(mua41) {
    case 0:
  var multiss5a = document.getElementById("41wav");
  multiss5a.play();
        break;
    case 1:
  var multiss5b = document.getElementById("41awav");
  multiss5b.play();
        break;
    case 2:
  var multiss5c = document.getElementById("41bwav");
  multiss5c.play();
        break;
    default:
  var multiss5d = document.getElementById("41cwav");
  multiss5d.play();
  }}

function multitouchess6a(mua42){
    switch(mua42) {
    case 0:
  var multiss6a = document.getElementById("42wav");
  multiss6a.play();
        break;
    case 1:
  var multiss6b = document.getElementById("42awav");
  multiss6b.play();
        break;
    case 2:
  var multiss6c = document.getElementById("42bwav");
  multiss6c.play();
        break;
    default:
  var multiss6d = document.getElementById("42cwav");
  multiss6d.play();
  }}

function multitouchess7a(mua43){
    switch(mua43) {
    case 0:
  var multiss7a = document.getElementById("43wav");
  multiss7a.play();
        break;
    case 1:
  var multiss7b = document.getElementById("43awav");
  multiss7b.play();
        break;
    case 2:
  var multiss7c = document.getElementById("43bwav");
  multiss7c.play();
        break;
    default:
  var multiss7d = document.getElementById("43cwav");
  multiss7d.play();
  }}

function multitouchess8a(mua44){
    switch(mua44) {
    case 0:
  var multiss8a = document.getElementById("44wav");
  multiss8a.play();
        break;
    case 1:
  var multiss8b = document.getElementById("44awav");
  multiss8b.play();
        break;
    case 2:
  var multiss8c = document.getElementById("44bwav");
  multiss8c.play();
        break;
    default:
  var multiss8d = document.getElementById("44cwav");
  multiss8d.play();
  }}

function multitouchess9a(mua45){
    switch(mua45) {
    case 0:
  var multiss9a = document.getElementById("45wav");
  multiss9a.play();
        break;
    case 1:
  var multiss9b = document.getElementById("45awav");
  multiss9b.play();
        break;
    case 2:
  var multiss9c = document.getElementById("45bwav");
  multiss9c.play();
        break;
    default:
  var multiss9d = document.getElementById("45cwav");
  multiss9d.play();
  }}

function multitouchess10a(mua46){
    switch(mua46) {
    case 0:
  var multiss10a = document.getElementById("46wav");
  multiss10a.play();
        break;
    case 1:
  var multiss10b = document.getElementById("46awav");
  multiss10b.play();
        break;
    case 2:
  var multiss10c = document.getElementById("46bwav");
  multiss10c.play();
        break;
    default:
  var multiss10d = document.getElementById("46cwav");
  multiss10d.play();
  }}

function multitouchess11a(mua47){
    switch(mua47) {
    case 0:
  var multiss11a = document.getElementById("47wav");
  multiss11a.play();
        break;
    case 1:
  var multiss11b = document.getElementById("47awav");
  multiss11b.play();
        break;
    case 2:
  var multiss11c = document.getElementById("47bwav");
  multiss11c.play();
        break;
    default:
  var multiss11d = document.getElementById("47cwav");
  multiss11d.play();
  }}

function multitouchess12a(mua48){
    switch(mua48) {
    case 0:
  var multiss12a = document.getElementById("48wav");
  multiss12a.play();
        break;
    case 1:
  var multiss12b = document.getElementById("48awav");
  multiss12b.play();
        break;
    case 2:
  var multiss12c = document.getElementById("48bwav");
  multiss12c.play();
        break;
    default:
  var multiss12d = document.getElementById("48cwav");
  multiss12d.play();
  }}

function multitouchess13a(mua49){
    switch(mua49) {
    case 0:
  var multiss13a = document.getElementById("49wav");
  multiss13a.play();
        break;
    case 1:
  var multiss13b = document.getElementById("49awav");
  multiss13b.play();
        break;
    case 2:
  var multiss13c = document.getElementById("49bwav");
  multiss13c.play();
        break;
    default:
  var multiss13d = document.getElementById("49cwav");
  multiss13d.play();
  }}





function touche1Press(){
	mua1 = Number(mua1) + 1;
	if(mua1>3){
        mua1 =0;
  	}
	multitouchea(mua1);
  }
function touche2Press(){
	mua2 = Number(mua2) + 1;
	if(mua2>3){
        mua2 =0;
  	}
	multitouchez(mua2);
  }
function touche3Press(){
	mua3 = Number(mua3) + 1;
	if(mua3>3){
        mua3 =0;
  	}
	multitouchee(mua3);
  }  
function touche4Press(){
	mua4 = Number(mua4) + 1;
	if(mua4>3){
        mua4 =0;
  	}
	multitoucher(mua4);
  }
function touche5Press(){
	mua5 = mua5 + 1;
	if(mua5>3){
        mua5 =0;
  	}
	multitouchet(mua5);
  }
function touche6Press(){
	mua6 = Number(mua6) + 1;
	if(mua6>3){
        mua6 =0;
  	}
	multitouchey(mua6);
  }
function touche7Press(){
	mua7 = Number(mua7) + 1;
	if(mua7>3){
        mua7 =0;
  	}
	multitoucheu(mua7);
  }
function touche8Press(){
	mua8 = Number(mua8) + 1;
	if(mua8>3){
        mua8 =0;
  	}
	multitouchei(mua8);
  }
function touche9Press(){
	mua9 = Number(mua9) + 1;
	if(mua9>3){
        mua9 =0;
  	}
	multitoucheo(mua9);
  }
function touche10Press(){
	mua10 = Number(mua10) + 1;
	if(mua10>3){
        mua10 =0;
  	}
	multitouchep(mua10);
  }
function touche11Press(){
	mua11 = Number(mua11) + 1;
	if(mua11>3){
        mua11 =0;
  	}
	multitoucheq(mua11);
  }
function touche12Press(){
	mua12 = Number(mua12) + 1;
	if(mua12>3){
        mua12 =0;
  	}
	multitouches(mua12);
  }
function touche13Press(){
	mua13 = Number(mua13) + 1;
	if(mua13>3){
        mua13 =0;
  	}
	multitouched(mua13);
  }
function touche14Press(){
	mua14 = Number(mua14) + 1;
	if(mua14>3){
        mua14 =0;
  	}
	multitouchef(mua14);
  }
function touche15Press(){
	mua15 = Number(mua15) + 1;
	if(mua15>3){
        mua15 =0;
  	}
	multitoucheg(mua15);
  } 
function touche16Press(){
	mua16 = Number(mua16) + 1;
	if(mua16>3){
        mua16 =0;
  	}
	multitoucheh(mua16);
  }
function touche17Press(){
	mua17 = Number(mua17) + 1;
	if(mua17>3){
        mua17 =0;
  	}
	multitouchej(mua17);
  }
function touche18Press(){
	mua18 = Number(mua18) + 1;
	if(mua18>3){
        mua18 =0;
  	}
	multitouchek(mua18);
  }  
function touche19Press(){
	mua19 = Number(mua19) + 1;
	if(mua19>3){
        mua19 =0;
  	}
	multitouchel(mua19);
  }
function touche20Press(){
	mua20 = Number(mua20) + 1;
	if(mua20>3){
        mua20 =0;
  	}
	multitouchem(mua20);
  }
function touche21Press(){
	mua21 = Number(mua21) + 1;
	if(mua21>3){
        mua21 =0;
  	}
	multitouchew(mua21);
  }
function touche22Press(){
	mua22 = Number(mua22) + 1;
	if(mua22>3){
        mua22 =0;
  	}
	multitouchex(mua22);
  }
function touche23Press(){
	mua23 = Number(mua23) + 1;
	if(mua23>3){
        mua23 =0;
  	}
	multitouched(mua23);
  }
function touche24Press(){
	mua24 = Number(mua24) + 1;
	if(mua24>3){
        mua24 =0;
  	}
	multitouchev(mua24);
  }
function touche25Press(){
	mua25 = Number(mua25) + 1;
	if(mua25>3){
        mua25 =0;
  	}
	multitoucheb(mua25);
  }
function touche26Press(){
	mua26 = Number(mua26) + 1;
	if(mua26>3){
        mua26 =0;
  	}
	multitouchen(mua26);
  }
function touche27Press(){
	mua27 = Number(mua27) + 1;
	if(mua27>3){
        mua27 =0;
  	}
	multitoucheno(mua27);
  }
function touche28Press(){
	mua28 = Number(mua28) + 1;
	if(mua28>3){
        mua28 =0;
  	}
	multitouche1(mua28);
  }
function touche29Press(){
	mua29 = Number(mua29) + 1;
	if(mua29>3){
        mua29 =0;
  	}
	multitouche2(mua29);
  }
function touche30Press(){
	mua30 = Number(mua30) + 1;
	if(mua30>3){
        mua30 =0;
  	}
	multitouche3(mua30);
  }
function touche31Press(){
	mua31 = Number(mua31) + 1;
	if(mua31>3){
        mua31 =0;
  	}
	multitouche4(mua31);
  }
function touche32Press(){
	mua32 = Number(mua32) + 1;
	if(mua32>3){
        mua32 =0;
  	}
	multitouche5(mua32);
  }
function touche33Press(){
	mua33 = Number(mua33) + 1;
	if(mua33>3){
        mua33 =0;
  	}
	multitouche6(mua33);
  }
function touche34Press(){
	mua34 = Number(mua34) + 1;
	if(mua34>3){
        mua34 =0;
  	}
	multitouche7(mua34);
  }
function touche35Press(){
	mua35 = Number(mua35) + 1;
	if(mua35>3){
        mua35 =0;
  	}
	multitouche8(mua35);
  } 
function touche36Press(){
	mua36 = Number(mua36) + 1;
	if(mua36>3){
        mua36 =0;
  	}
	multitouche9(mua36);
  }  

function touche37Press(){
	mua37 = Number(mua37) + 1;
	if(mua37>3){
        mua37 =0;
  	}
	multitouchess1a(mua37);
  }
function touche38Press(){
	mua38 = Number(mua38) + 1;
	if(mua38>3){
        mua38 =0;
  	}
	multitouchess2a(mua38);
  }
function touche39Press(){
	mua39 = Number(mua39) + 1;
	if(mua39>3){
        mua39 =0;
  	}
	multitouchess3a(mua39);
  }
function touche40Press(){
	mua40 = Number(mua40) + 1;
	if(mua40>3){
        mua40 =0;
  	}
	multitouchess4a(mua40);
  }
function touche41Press(){
	mua41 = Number(mua41) + 1;
	if(mua41>3){
        mua41 =0;
  	}
	multitouchess5a(mua41);
  }
function touche42Press(){
	mua42 = Number(mua42) + 1;
	if(mua42>3){
        mua42 =0;
  	}
	multitouchess6a(mua42);
  }
function touche43Press(){
	mua43 = Number(mua43) + 1;
	if(mua43>3){
        mua43 =0;
  	}
	multitouchess7a(mua43);
  }
function touche44Press(){
	mua44 = Number(mua44) + 1;
	if(mua44>3){
        mua44 =0;
  	}
	multitouchess8a(mua44);
  }
function touche45Press(){
	mua45 = Number(mua45) + 1;
	if(mua45>3){
        mua45 =0;
  	}
	multitouchess9a(mua45);
  } 
function touche46Press(){
	mua46 = Number(mua46) + 1;
	if(mua46>3){
        mua46 =0;
  	}
	multitouchess10a(mua46);
  }
function touche47Press(){
	mua47 = Number(mua47) + 1;
	if(mua47>3){
        mua47 =0;
  	}
	multitouchess11a(mua47);
  }  
function touche48Press(){
	mua48 = Number(mua48) + 1;
	if(mua48>3){
        mua48 =0;
  	}
	multitouchess12a(mua48);
  }

function touche49Press(){
	mua49 = Number(mua49) + 1;
	if(mua49>3){
        mua49 =0;
  	}
	multitouchess13a(mua49);
  }  

window.addEventListener("keydown", function (event) {
  if (event.defaultPrevented) {
    return; // Should do nothing if the key event was already consumed.
  }

  switch (event.key) {
    	case "a":
	mua1 = mua1 + 1;
	if(mua1>3){
        mua1 =0;
  	}
	multitouchea(mua1);
   	break;
   	
    	case "z":
    	mua2 = mua2 + 1;
	if(mua2>3){
        mua2 =0;
  	}
	multitouchez(mua2);
   	break;
   	
    	case "e":
    	mua3 = mua3 + 1;
	if(mua3>3){
        mua3 =0;
  	}
	multitouchee(mua3);
   	break;
   	
    	case "r":
    	mua4 = mua4 + 1;
	if(mua4>3){
        mua4 =0;
  	}
	multitoucher(mua4);
   	break;
   	
    	case "t":
    	mua5 = mua5 + 1;
	if(mua5>3){
        mua5 =0;
  	}
	multitouchet(mua5);
   	break;
   	
    	case "y":
    	mua6 = mua6 + 1;
	if(mua6>3){
        mua6 =0;
  	}
	multitouchet(mua6);
   	break;
   	
    	case "u":
    	mua7 = mua7 + 1;
	if(mua7>3){
        mua7 =0;
  	}
	multitoucheu(mua7);
   	break;
   	
    	case "i":
    	mua8 = mua8 + 1;
	if(mua8>3){
        mua8 =0;
  	}
	multitouchei(mua8);
   	break;
   	
    	case "o":
    	mua9 = mua9 + 1;
	if(mua9>3){
        mua9 =0;
  	}
	multitoucheo(mua9);
   	break;
   	
    	case "p":
    	mua10 = mua10 + 1;
	if(mua10>3){
        mua10 =0;
  	}
	multitouchep(mua10);
   	break;
   	
    	case "q":
    	mua11 = mua11 + 1;
	if(mua11>3){
        mua11 =0;
  	}
	multitoucheq(mua11);
   	break;
   	
    	case "s":
    	mua12 = mua12 + 1;
	if(mua12>3){
        mua12 =0;
  	}
	multitouches(mua12);
   	break;
   	
    	case "d":
    	mua13 = mua13 + 1;
	if(mua13>3){
        mua13 =0;
  	}
	multitouched(mua13);
   	break;
   	
    	case "f":
    	mua14 = mua14 + 1;
	if(mua14>3){
        mua14 =0;
  	}
	multitouchef(mua14);
   	break;
   	
    	case "g":
    	mua15 = mua15 + 1;
	if(mua15>3){
        mua15 =0;
  	}
	multitoucheg(mua15);
   	break;
   	
    	case "h":
    	mua16 = mua16 + 1;
	if(mua16>3){
        mua16 =0;
  	}
	multitoucheh(mua16);
   	break;
   	
    	case "j":
    	mua17 = mua17 + 1;
	if(mua17>3){
        mua17 =0;
  	}
	multitouchej(mua17);
   	break;
   	
    	case "k":
    	mua18 = mua18 + 1;
	if(mua18>3){
        mua18 =0;
  	}
	multitouchek(mua18);
   	break;
   	
    	case "l":
    	mua19 = mua19 + 1;
	if(mua19>3){
        mua19 =0;
  	}
	multitouchel(mua19);
   	break;
   	
    	case "m":
    	mua20 = mua20 + 1;
	if(mua20>3){
        mua20 =0;
  	}
	multitouchem(mua20);
   	break;
   	
    	case "w":
    	mua21 = mua21 + 1;
	if(mua21>3){
        mua21 =0;
  	}
	multitouchew(mua21);
   	break;
   	
    	case "x":
    	mua22 = mua22 + 1;
	if(mua22>3){
        mua22 =0;
  	}
	multitouchex(mua22);
   	break;
   	
    	case "c":
    	mua23 = mua23 + 1;
	if(mua23>3){
        mua23 =0;
  	}
	multitouchec(mua23);
   	break;
   	
    	case "v":
    	mua24 = mua24 + 1;
	if(mua24>3){
        mua24 =0;
  	}
	multitouchev(mua24);
   	break;
   	
    	case "b":
    	mua25 = mua25 + 1;
	if(mua25>3){
        mua25 =0;
  	}
	multitoucheb(mua25);
   	break;
   	
    	case "n":
    	mua26 = mua26 + 1;
	if(mua26>3){
        mua26 =0;
  	}
	multitouchen(mua26);
   	break;
   	
    	case "0":
    	mua27 = mua27 + 1;
	if(mua27>3){
        mua27 =0;
  	}
	multitoucheno(mua27);
   	break;
   	
    	case "1":
    	mua28 = mua28 + 1;
	if(mua28>3){
        mua28 =0;
  	}
	multitouche1(mua28);
   	break;
   	
    	case "2":
    	mua29 = mua29 + 1;
	if(mua29>3){
        mua29 =0;
  	}
	multitouche2(mua29);
   	break;
   	
    	case "3":
    	mua30 = mua30 + 1;
	if(mua30>3){
        mua30 =0;
  	}
	multitouche3(mua30);
   	break;
   	
    	case "4":
    	mua31 = mua31 + 1;
	if(mua31>3){
        mua31 =0;
  	}
	multitouche4(mua31);
   	break;
   	
    	case "5":
    	mua32 = mua32 + 1;
	if(mua32>3){
        mua32 =0;
  	}
	multitouche5(mua32);
   	break;
   	
    	case "6":
    	mua33 = mua33 + 1;
	if(mua33>3){
        mua33 =0;
  	}
	multitouche6(mua33);
   	break;
   	
    	case "7":
    	mua34 = mua34 + 1;
	if(mua34>3){
        mua34 =0;
  	}
	multitouche7(mua34);
   	break;
   	
    	case "8":
    	mua35 = mua35 + 1;
	if(mua35>3){
        mua35 =0;
  	}
	multitouche8(mua35);
   	break;
   	
    	case "9":
    	mua36 = mua36 + 1;
	if(mua36>3){
        mua36 =0;
  	}
	multitouche9(mua36);
   	break;


    default:
 
      return; // Quit when this doesn't handle the key event.
  }

  // Consume the event for suppressing "double action".
  event.preventDefault();
}, true);

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('b1v').addEventListener("click", function() {
touche1Press();
});
document.getElementById('b2v').addEventListener("click", function() {
touche2Press();
});
document.getElementById('b3v').addEventListener("click", function() {
touche3Press();
});
document.getElementById('b4v').addEventListener("click", function() {
touche4Press();
});
document.getElementById('b5v').addEventListener("click", function() {
touche5Press();
});
document.getElementById('b6v').addEventListener("click", function() {
touche6Press();
});
document.getElementById('b7v').addEventListener("click", function() {
touche7Press();
});
document.getElementById('b8v').addEventListener("click", function() {
touche8Press();
});
document.getElementById('b9v').addEventListener("click", function() {
touche9Press();
});
document.getElementById('b10v').addEventListener("click", function() {
touche10Press();
});
document.getElementById('b11v').addEventListener("click", function() {
touche11Press();
});
document.getElementById('b12v').addEventListener("click", function() {
touche12Press();
});
document.getElementById('b13v').addEventListener("click", function() {
touche13Press();
});
document.getElementById('b14v').addEventListener("click", function() {
touche14Press();
});
document.getElementById('b15v').addEventListener("click", function() {
touche15Press();
});
document.getElementById('b16v').addEventListener("click", function() {
touche16Press();
});
document.getElementById('b17v').addEventListener("click", function() {
touche17Press();
});
document.getElementById('b18v').addEventListener("click", function() {
touche18Press();
});
document.getElementById('b19v').addEventListener("click", function() {
touche19Press();
});
document.getElementById('b20v').addEventListener("click", function() {
touche20Press();
});
document.getElementById('b21v').addEventListener("click", function() {
touche21Press();
});

    document.getElementById('b22v').addEventListener("click", function() {
    touche22Press();
    });
    document.getElementById('b23v').addEventListener("click", function() {
    touche23Press();
    });
    document.getElementById('b24v').addEventListener("click", function() {
    touche24Press();
    });
    document.getElementById('b25v').addEventListener("click", function() {
    touche25Press();
    });
    document.getElementById('b26v').addEventListener("click", function() {
    touche26Press();
    });
    document.getElementById('b27v').addEventListener("click", function() {
    touche27Press();
    });
    document.getElementById('b28v').addEventListener("click", function() {
    touche28Press();
    });
    document.getElementById('b29v').addEventListener("click", function() {
    touche29Press();
    });
    document.getElementById('b30v').addEventListener("click", function() {
    touche30Press();
    });
    document.getElementById('b31v').addEventListener("click", function() {
    touche31Press();
    });
    document.getElementById('b32v').addEventListener("click", function() {
    touche32Press();
    });
    document.getElementById('b33v').addEventListener("click", function() {
    touche33Press();
    });
    document.getElementById('b34v').addEventListener("click", function() {
    touche34Press();
    });
    document.getElementById('b35v').addEventListener("click", function() {
    touche35Press();
    });
    document.getElementById('b36v').addEventListener("click", function() {
    touche36Press();
    });
    document.getElementById('b37v').addEventListener("click", function() {
    touche37Press();
    });
    document.getElementById('b38v').addEventListener("click", function() {
    touche38Press();
    });
    document.getElementById('b39v').addEventListener("click", function() {
    touche39Press();
    });
    document.getElementById('b40v').addEventListener("click", function() {
    touche40Press();
    });
    document.getElementById('b41v').addEventListener("click", function() {
    touche41Press();
    });
    document.getElementById('b42v').addEventListener("click", function() {
    touche42Press();
    });
    document.getElementById('b43v').addEventListener("click", function() {
    touche43Press();
    });
    document.getElementById('b44v').addEventListener("click", function() {
    touche44Press();
    });
    document.getElementById('b45v').addEventListener("click", function() {
    touche45Press();
    });
    document.getElementById('b46v').addEventListener("click", function() {
    touche46Press();
    });
    document.getElementById('b47v').addEventListener("click", function() {
    touche47Press();
    });
    document.getElementById('b48v').addEventListener("click", function() {
    touche48Press();
    });
    document.getElementById('b49v').addEventListener("click", function() {
    touche49Press();
    });

});
  
  

